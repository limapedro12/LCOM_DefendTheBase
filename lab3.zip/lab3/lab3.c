#include <lcom/lcf.h>

#include <lcom/lab3.h>

#include <stdbool.h>
#include <stdint.h>

#include "i8042.h"
#include "keyboard.h"
#include "timer.h"
#include "utils.h"

int kbd_subscribe_int(u8_t*);
int kbd_unsubscribe_int();
int kbd_activate_int();
u8_t kbd_read_cb();
int kbd_write_cb(u8_t);

//#include "keyboard.h"
extern u8_t code;
extern int cnt;
extern int counter;
// u8_t code = 0;

int main(int argc, char *argv[]) {
  // sets the language of LCF messages (can be either EN-US or PT-PT)
  lcf_set_language("EN-US");

  // enables to log function invocations that are being "wrapped" by LCF
  // [comment this out if you don't want/need it]
  lcf_trace_calls("/home/lcom/labs/lab3/trace.txt");

  // enables to save the output of printf function calls on a file
  // [comment this out if you don't want/need it]
  lcf_log_output("/home/lcom/labs/lab3/output.txt");

  // handles control over to LCF
  // [LCF handles command line arguments and invokes the right function]
  if (lcf_start(argc, argv))
    return 1;

  // LCF clean up tasks
  // [must be the last statement before return]
  lcf_cleanup();

  return 0;
}

int(kbd_test_scan)() {
  u8_t key = 30;
  int irq_set = BIT(key);

  // kbd_activate_int();

  kbd_subscribe_int(&key);

  int ipc_status = 0;
  message msg;
  int r;
  unsigned int safe_counter = 0;
  u8_t code_array[2];
  int a_meio = 0;
  while(code != 0x81){
    safe_counter++;
    //printf("Counter : %d\n", safe_counter);

    r = driver_receive(ANY, &msg, &ipc_status);
    if( r != 0 ) {
      printf("driver_receive failed with: %d", r);
      continue;
    }

    if (is_ipc_notify(ipc_status) && 
         _ENDPOINT_P(msg.m_source) == HARDWARE &&
         (msg.m_notify.interrupts & irq_set)){

          // printf("Im in!!!\n");
          // break;
          kbc_ih();
          if(a_meio){
            code_array[1] = code;
            kbd_print_scancode(!(code >> 7), 2, code_array);
            a_meio = 0;
          }else if(code == 0xE0){
            code_array[0] = code;
            a_meio = 1;
          } else
            kbd_print_scancode(!(code >> 7), 1, &code);
    }
  }

  kbd_unsubscribe_int();

  #ifdef LAB3
    kbd_print_no_sysinb(cnt);
  #endif

  return 0;
}

int(kbd_test_poll)() {
  // lcf_start();

  unsigned stat;
  u8_t data = 0;
  u8_t code_array[2];
  int a_meio = 0;

  while(data != 0x81) {
    sys_inb(KBC_ST_REG, &stat); /* assuming it returns OK */
    #ifdef LAB3
      cnt++;
    #endif
    /* loop while 8042 output buffer is empty */
    if( stat & KBC_OBF ) {
      util_sys_inb(KBC_OUT_BUF, &data); /* ass. it returns OK */
      #ifdef LAB3
        cnt++;
      #endif
      if ( (stat &(KBC_PAR_ERR | KBC_TO_ERR)) != 0 ){
        printf("Error!\n");
        break;
      }
      if(a_meio){
        code_array[1] = data;
        kbd_print_scancode(!(data >> 7), 2, code_array);
        a_meio = 0;
      }else if(data == 0xE0){
        code_array[0] = data;
        a_meio = 1;
      } else
        kbd_print_scancode(!(data >> 7), 1, &data);
        
    }
    tickdelay(micros_to_ticks(200)); // e.g. tickdelay()
  } 

  u8_t k = kbd_read_cb();
  kbd_write_cb((k & ~BIT(4)) | BIT(0));

  #ifdef LAB3
    kbd_print_no_sysinb(cnt);
  #endif

  return 0;
}

int(kbd_test_timed_scan)(uint8_t n) {
  u8_t key_kb = 30;
  int irq_set_kb = BIT(key_kb);

  u8_t key_tm = 31;
  int irq_set_tm = BIT(key_tm);

  // kbd_activate_int();

  timer_subscribe_int(&key_tm);
  kbd_subscribe_int(&key_kb);

  int ipc_status = 0;
  message msg;
  int r;
  unsigned int safe_counter = 0;
  u8_t code_array[2];
  int a_meio = 0;
  while(code != 0x81 && counter < n * 60){
    safe_counter++;
    //printf("Counter : %d\n", safe_counter);

    r = driver_receive(ANY, &msg, &ipc_status);
    if( r != 0 ) {
      printf("driver_receive failed with: %d", r);
      continue;
    }

    if (is_ipc_notify(ipc_status) && 
         _ENDPOINT_P(msg.m_source) == HARDWARE){
      if(msg.m_notify.interrupts & irq_set_kb){
        kbc_ih();
        if(a_meio){
          code_array[1] = code;
          kbd_print_scancode(!(code >> 7), 2, code_array);
          a_meio = 0;
        }else if(code == 0xE0){
          code_array[0] = code;
          a_meio = 1;
        } else
          kbd_print_scancode(!(code >> 7), 1, &code);
      }

      if(msg.m_notify.interrupts & irq_set_tm) { /* subscribed interrupt */
          timer_int_handler();
      }
    }
  }

  kbd_unsubscribe_int();

  #ifdef LAB3
    kbd_print_no_sysinb(cnt);
  #endif

  return 0;
}

