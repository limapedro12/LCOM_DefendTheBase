#include "keyboard.h"

int hook_id;
u8_t code = 0;
int cnt = 0;

void (kbc_ih)() {

  u8_t data;
  // util_sys_inb(0x60, &data);
  // code = data;

  uint stat;
  while(1) {
    sys_inb(KBC_ST_REG, &stat); /* assuming it returns OK */
    #ifdef LAB3
      cnt++;
    #endif
    /* loop while 8042 output buffer is empty */
    if( stat & KBC_OBF ) {
      util_sys_inb(KBC_OUT_BUF, &data); /* ass. it returns OK */
      #ifdef LAB3
        cnt++;
      #endif
      if ( (stat &(KBC_PAR_ERR | KBC_TO_ERR)) == 0 )
        code = data;
      else
        code =  -1;
      return;
      }
    // tickdelay(2000); // e.g. tickdelay()
  }
}

int (kbd_subscribe_int)(uint8_t* bit_no) {
  hook_id = *bit_no;
  sys_irqsetpolicy(KBD_IRQ, IRQ_REENABLE | IRQ_EXCLUSIVE, &hook_id);

  return 0;
}

int (kbd_unsubscribe_int)() {
  //printf("");
  sys_irqrmpolicy(&hook_id);
  return 0;
}

int (kbd_activate_int)(){
  unsigned stat;
  unsigned data;

  while( 1 ) {
    sys_inb(KBC_ST_REG, &stat); /* assuming it returns OK */
    #ifdef LAB3
      cnt++;
    #endif
    /* loop while 8042 output buffer is empty */
    if( stat & KBC_OBF ) {
      sys_inb(KBC_OUT_BUF, &data); /* ass. it returns OK */
      #ifdef LAB3
        cnt++;
      #endif
      if ( (stat &(KBC_PAR_ERR | KBC_TO_ERR)) != 0 )
        return 1;
      break;
    }
    tickdelay(micros_to_ticks(WAIT_KBC)); // e.g. tickdelay()
  } 
  
  unsigned cmd = (data & (~BIT(4))) | BIT(0);

  while( 1 ) {
    sys_inb(KBC_ST_REG, &stat); /* assuming it returns OK */
    #ifdef LAB3
      cnt++;
    #endif
    /* loop while 8042 input buffer is not empty */
    if( (stat & KBC_ST_IBF) == 0 ) {
      sys_outb(KBC_CMD_REG, cmd); /* no args command */
      return 0;
    }
    tickdelay(micros_to_ticks(WAIT_KBC)); // e.g. tickdelay()
  }
  return 0;
}

u8_t (kbd_read_cb)(){
  unsigned stat;
  u8_t data;

  sys_outb(KBC_CMD_REG, 0x20);

  while( 1 ) {
    sys_inb(KBC_ST_REG, &stat); /* assuming it returns OK */
    #ifdef LAB3
      cnt++;
    #endif
    /* loop while 8042 output buffer is empty */
    if( stat & KBC_OBF ) {
      util_sys_inb(KBC_OUT_BUF, &data); /* ass. it returns OK */
      #ifdef LAB3
        cnt++;
      #endif
      if ( (stat &(KBC_PAR_ERR | KBC_TO_ERR)) == 0 )
        return data;
      else
        return -1;
    }
    tickdelay(micros_to_ticks(WAIT_KBC)); // e.g. tickdelay()
  } 
}

int(kbd_write_cb)(u8_t cmd){
  uint stat;
  while( 1 ) {
    sys_inb(KBC_ST_REG, &stat); /* assuming it returns OK */
    #ifdef LAB3
      cnt++;
    #endif
    /* loop while 8042 input buffer is not empty */
    if( (stat & KBC_ST_IBF) == 0 ) {
      sys_outb(KBC_CMD_REG, 0x60);
      sys_outb(0x60, cmd); /* no args command */
      return 0;
    }
    tickdelay(micros_to_ticks(WAIT_KBC)); // e.g. tickdelay()
  }
  return 0;
}
