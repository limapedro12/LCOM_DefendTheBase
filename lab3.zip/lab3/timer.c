#include "timer.h"

int counter = 0;
int hook_id = 0;

u16_t (bin_to_bcd)(u16_t val) {
  u16_t bcd = 0;
  u16_t power = 1;
  while (val > 0) {
    u16_t digit = val % 10;
    bcd += digit * power;
    power *= 16;
    val /= 10;
  }
  return bcd;
}

int (timer_set_frequency)(uint8_t timer, uint32_t freq) {
  u8_t byte = 0;
  if(timer_get_conf(timer, &byte))
    return 1;

  u8_t mask = BIT(4) - 1;
  byte &= mask;
  byte |= TIMER_LSB_MSB;
  byte |= (u8_t) (timer << 6);

  long time_div = TIMER_FREQ / freq;
  if(time_div > UINT16_MAX){
    printf("Frequency too low\n");
    return 1;
  }

  u16_t time = time_div;
  if(byte & TIMER_BCD)
    time = bin_to_bcd(time);

  u8_t lsb, msb;
  util_get_LSB(time, &lsb);
  util_get_MSB(time, &msb);

  sys_outb(TIMER_0 + timer, 0);
  sys_outb(TIMER_CTRL, byte);
  sys_outb(TIMER_0 + timer, lsb);
  sys_outb(TIMER_0 + timer, msb);

  // printf("byte: %x", BIT(5) - 1);

  return 0;
}

int (timer_subscribe_int)(uint8_t *bit_no) {
  hook_id = *bit_no;
  sys_irqsetpolicy(TIMER0_IRQ, IRQ_REENABLE, &hook_id);

  return 0;
}

int (timer_unsubscribe_int)() {
  //printf("hook_id timer: %d\n", hook_id);
  sys_irqrmpolicy(&hook_id);
  return 0;
}

void (timer_int_handler)() {
  counter++;
}

int (timer_get_conf)(uint8_t timer, uint8_t *st) {
  u8_t command = TIMER_RB_CMD | TIMER_RB_COUNT_ | TIMER_RB_SEL(timer);
  sys_outb(TIMER_CTRL, command);

  u8_t byte;
  util_sys_inb(TIMER_0 + timer, &byte);
  *st = (uint8_t) byte;

  return 0;
}

int (timer_display_conf)(uint8_t timer, uint8_t st,
                        enum timer_status_field field) {
  union timer_status_field_val val;
  switch (field) {
    case tsf_all:
      val.byte = st;
      break;
    case tsf_initial:
      val.in_mode = (u8_t)(st & TIMER_LSB_MSB) >> 4;
      break;
    case tsf_mode:
      val.count_mode = (u8_t)(st & (BIT(1) | BIT(2) | BIT(3))) >> 1;
      break;
    case tsf_base:
      val.bcd = st & TIMER_BCD;
      break;
    default:
      break;
  }

  timer_print_config(timer, field, val);

  return 0;
}
