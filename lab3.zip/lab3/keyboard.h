#include <lcom/lcf.h>
#include "i8042.h"
#include "utils.h"

int kbd_subscribe_int(u8_t*);
int kbd_unsubscribe_int();
int kbd_activate_int();
u8_t kbd_read_cb();
int kbd_write_cb(u8_t);

// void (kbc_ih)();
